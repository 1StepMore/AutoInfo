# End-User Coverage Matrix (E8, issue #131)

- Spec: `docs/dev/specs/end-user-matrix.yaml`
- Spec version: 2
- Evidence dir: `outputs`
- LLM available: no (llm_gated products are 未配置unconfigured, not gaps)
- Generated: 2026-08-07T19:18:48.330501+00:00
- Cells: 728 (domains=13 x products=8 x formats=7), required=112 — produced=0, gap=28, unconfigured=84, not-applicable=616

## Legend

| Symbol | Status | Meaning |
|--------|--------|---------|
| 有 | 有produced | Evidence found for this domain x product x format |
| 空 | 空gap | Required cell with no evidence (LLM available or product not LLM-gated) |
| 不适用 | 不适用not-applicable | Non-required cell with no evidence |
| 未配置 | 未配置unconfigured | Required LLM-gated cell while the LLM key is unavailable (not a gap) |

## Matrix (rows = products, columns = domains)

| Product | medical-research | ai-commercial | financial-intelligence | tech-ai-developer | language-learning | online-video | financial-news | online-education | legal-compliance | general-news | gaming | b2b | retail |
|---------|---|---|---|---|---|---|---|---|---|---|---|---|---|
| digest | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| report | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| tutorial | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| presentation | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| premium-briefing | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| column | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| magazine-digest | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| enterprise-briefing | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 未配置unconfigured | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |

## COVERAGE_GAP

Required cells with NO produced evidence and NOT LLM-unconfigured (these block acceptance — issue #131):

| Domain | Product | Format |
|--------|---------|--------|
| medical-research | digest | agent |
| medical-research | digest | audio |
| medical-research | digest | audiobook |
| medical-research | digest | epub |
| medical-research | digest | html |
| medical-research | digest | json |
| medical-research | digest | markdown |
| medical-research | report | agent |
| medical-research | report | audio |
| medical-research | report | audiobook |
| medical-research | report | epub |
| medical-research | report | html |
| medical-research | report | json |
| medical-research | report | markdown |
| tech-ai-developer | digest | agent |
| tech-ai-developer | digest | audio |
| tech-ai-developer | digest | audiobook |
| tech-ai-developer | digest | epub |
| tech-ai-developer | digest | html |
| tech-ai-developer | digest | json |
| tech-ai-developer | digest | markdown |
| tech-ai-developer | report | agent |
| tech-ai-developer | report | audio |
| tech-ai-developer | report | audiobook |
| tech-ai-developer | report | epub |
| tech-ai-developer | report | html |
| tech-ai-developer | report | json |
| tech-ai-developer | report | markdown |

## SOURCE_COVERAGE

Required source-platform cells (domain x source) with no collected raw data — these block acceptance for the configured demo domains:

| Domain | Source |
|--------|--------|
| medical-research | pubmed |
| medical-research | semantic-scholar |
| medical-research | arXiv |
| medical-research | CrossRef |
| medical-research | dblp |
| medical-research | openalex |
| medical-research | uspto |
| tech-ai-developer | GitHub Trending |
| tech-ai-developer | HackerNews API |
| tech-ai-developer | Substack RSS (tech) — Pragmatic Engineer |
| tech-ai-developer | Stack Exchange |
| tech-ai-developer | ProductHunt |
| tech-ai-developer | Reddit |

## KB_TIER_COVERAGE

Required KB-tier cells (domain x tier) with no entries — the pipeline must reach each tier for the configured demo domains:

| Domain | Tier |
|--------|------|
| medical-research | 01-Raw |
| medical-research | 02-Draft |
| medical-research | 03-Wiki |
| tech-ai-developer | 01-Raw |
| tech-ai-developer | 02-Draft |
| tech-ai-developer | 03-Wiki |

## SCENARIO_LIBRARY_COVERAGE

Capabilities the validation scenario library actually exercises vs the full implemented surface (spec products/formats/sources). A capability the library never touches is invisible to acceptance:

- Products exercised: 8/8 — missing: none
- Formats exercised: 7/7 — missing: none
- Source tokens exercised: 41/27 (best-effort text scan) — missing: none

