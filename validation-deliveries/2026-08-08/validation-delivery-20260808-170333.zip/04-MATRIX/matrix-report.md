# End-User Coverage Matrix (E8, issue #131)

- Spec: `/mnt/d/贯维/AutoInfo/docs/dev/specs/end-user-matrix.yaml`
- Spec version: 2
- Evidence dir: `validation-deliveries/2026-08-08/validation-delivery-20260808-170333`
- LLM available: yes
- Generated: 2026-08-08T09:04:25.307285+00:00
- Cells: 728 (domains=13 x products=8 x formats=7), required=112 — produced=0, gap=112, unconfigured=0, not-applicable=616

## Legend

| Symbol | Status | Meaning |
|--------|--------|---------|
| 有 | 有produced | Evidence found for this domain x product x format |
| 空 | 空gap | Required cell with no evidence (LLM available or product not LLM-gated) |
| 不适用 | 不适用not-applicable | Non-required cell with no evidence |
| 未配置 | 未配置unconfigured | Required LLM-gated cell while the LLM key is unavailable (not a gap) |

## Matrix (rows = products, columns = domains)

| Product | medical-research | ai-commercial | financial-intelligence | tech-ai-developer | language-learning | online-video | financial-news | online-education | legal-compliance | general-news | gaming | b2b | retail |
|---------|---|---|---|---|---|---|---|---|---|---|---|---|---|
| digest | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| report | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| tutorial | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| presentation | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| premium-briefing | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| column | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| magazine-digest | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |
| enterprise-briefing | 空gap | 不适用not-applicable | 不适用not-applicable | 空gap | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable | 不适用not-applicable |

## COVERAGE_GAP

Required cells with NO produced evidence and NOT LLM-unconfigured (these block acceptance — issue #131):

| Domain | Product | Format |
|--------|---------|--------|
| medical-research | column | agent |
| medical-research | column | audio |
| medical-research | column | audiobook |
| medical-research | column | epub |
| medical-research | column | html |
| medical-research | column | json |
| medical-research | column | markdown |
| medical-research | digest | agent |
| medical-research | digest | audio |
| medical-research | digest | audiobook |
| medical-research | digest | epub |
| medical-research | digest | html |
| medical-research | digest | json |
| medical-research | digest | markdown |
| medical-research | enterprise-briefing | agent |
| medical-research | enterprise-briefing | audio |
| medical-research | enterprise-briefing | audiobook |
| medical-research | enterprise-briefing | epub |
| medical-research | enterprise-briefing | html |
| medical-research | enterprise-briefing | json |
| medical-research | enterprise-briefing | markdown |
| medical-research | magazine-digest | agent |
| medical-research | magazine-digest | audio |
| medical-research | magazine-digest | audiobook |
| medical-research | magazine-digest | epub |
| medical-research | magazine-digest | html |
| medical-research | magazine-digest | json |
| medical-research | magazine-digest | markdown |
| medical-research | premium-briefing | agent |
| medical-research | premium-briefing | audio |
| medical-research | premium-briefing | audiobook |
| medical-research | premium-briefing | epub |
| medical-research | premium-briefing | html |
| medical-research | premium-briefing | json |
| medical-research | premium-briefing | markdown |
| medical-research | presentation | agent |
| medical-research | presentation | audio |
| medical-research | presentation | audiobook |
| medical-research | presentation | epub |
| medical-research | presentation | html |
| medical-research | presentation | json |
| medical-research | presentation | markdown |
| medical-research | report | agent |
| medical-research | report | audio |
| medical-research | report | audiobook |
| medical-research | report | epub |
| medical-research | report | html |
| medical-research | report | json |
| medical-research | report | markdown |
| medical-research | tutorial | agent |
| medical-research | tutorial | audio |
| medical-research | tutorial | audiobook |
| medical-research | tutorial | epub |
| medical-research | tutorial | html |
| medical-research | tutorial | json |
| medical-research | tutorial | markdown |
| tech-ai-developer | column | agent |
| tech-ai-developer | column | audio |
| tech-ai-developer | column | audiobook |
| tech-ai-developer | column | epub |
| tech-ai-developer | column | html |
| tech-ai-developer | column | json |
| tech-ai-developer | column | markdown |
| tech-ai-developer | digest | agent |
| tech-ai-developer | digest | audio |
| tech-ai-developer | digest | audiobook |
| tech-ai-developer | digest | epub |
| tech-ai-developer | digest | html |
| tech-ai-developer | digest | json |
| tech-ai-developer | digest | markdown |
| tech-ai-developer | enterprise-briefing | agent |
| tech-ai-developer | enterprise-briefing | audio |
| tech-ai-developer | enterprise-briefing | audiobook |
| tech-ai-developer | enterprise-briefing | epub |
| tech-ai-developer | enterprise-briefing | html |
| tech-ai-developer | enterprise-briefing | json |
| tech-ai-developer | enterprise-briefing | markdown |
| tech-ai-developer | magazine-digest | agent |
| tech-ai-developer | magazine-digest | audio |
| tech-ai-developer | magazine-digest | audiobook |
| tech-ai-developer | magazine-digest | epub |
| tech-ai-developer | magazine-digest | html |
| tech-ai-developer | magazine-digest | json |
| tech-ai-developer | magazine-digest | markdown |
| tech-ai-developer | premium-briefing | agent |
| tech-ai-developer | premium-briefing | audio |
| tech-ai-developer | premium-briefing | audiobook |
| tech-ai-developer | premium-briefing | epub |
| tech-ai-developer | premium-briefing | html |
| tech-ai-developer | premium-briefing | json |
| tech-ai-developer | premium-briefing | markdown |
| tech-ai-developer | presentation | agent |
| tech-ai-developer | presentation | audio |
| tech-ai-developer | presentation | audiobook |
| tech-ai-developer | presentation | epub |
| tech-ai-developer | presentation | html |
| tech-ai-developer | presentation | json |
| tech-ai-developer | presentation | markdown |
| tech-ai-developer | report | agent |
| tech-ai-developer | report | audio |
| tech-ai-developer | report | audiobook |
| tech-ai-developer | report | epub |
| tech-ai-developer | report | html |
| tech-ai-developer | report | json |
| tech-ai-developer | report | markdown |
| tech-ai-developer | tutorial | agent |
| tech-ai-developer | tutorial | audio |
| tech-ai-developer | tutorial | audiobook |
| tech-ai-developer | tutorial | epub |
| tech-ai-developer | tutorial | html |
| tech-ai-developer | tutorial | json |
| tech-ai-developer | tutorial | markdown |

## SOURCE_COVERAGE

Required source-platform cells (domain x source) with no collected raw data — these block acceptance for the configured demo domains:

| Domain | Source |
|--------|--------|
| medical-research | pubmed |
| medical-research | semantic-scholar |
| medical-research | arXiv |
| medical-research | CrossRef |
| medical-research | dblp |
| medical-research | openalex |
| medical-research | uspto |
| tech-ai-developer | GitHub Trending |
| tech-ai-developer | HackerNews API |
| tech-ai-developer | Substack RSS (tech) — Pragmatic Engineer |
| tech-ai-developer | Stack Exchange |
| tech-ai-developer | ProductHunt |
| tech-ai-developer | Reddit |

## KB_TIER_COVERAGE

Required KB-tier cells (domain x tier) with no entries — the pipeline must reach each tier for the configured demo domains:

| Domain | Tier |
|--------|------|
| medical-research | 01-Raw |
| medical-research | 02-Draft |
| medical-research | 03-Wiki |
| tech-ai-developer | 01-Raw |
| tech-ai-developer | 02-Draft |
| tech-ai-developer | 03-Wiki |

## SCENARIO_LIBRARY_COVERAGE

Capabilities the validation scenario library actually exercises vs the full implemented surface (spec products/formats/sources). A capability the library never touches is invisible to acceptance:

- Products exercised: 0/8 — missing: column, digest, enterprise-briefing, magazine-digest, premium-briefing, presentation, report, tutorial
- Formats exercised: 0/7 — missing: agent, audio, audiobook, epub, html, json, markdown
- Source tokens exercised: 0/27 (best-effort text scan) — missing: akshare, ap_api, api, apple_podcasts, bilibili, core, dblp, edx_sitemap, email, gdelt, huggingface, kaggle, nyt, openalex, pdf, quandl, reddit, reuters, rss, sec_edgar, spotify, ssrn, unpaywall, web, webhook, yahoo_finance, youtube

