# AutoInfo Validation Delivery Report

- Date: 20260808-033605
- Scenarios: 54 (passed=39, failed=0, unconfigured=15, skipped=0)
- Artifacts: 105 delivered, 175 rejected
- Domains: medical-research, ai-commercial, tech-ai-developer, language-learning, financial-intelligence

## Scenario Status

| Scenario | Status | Summary |
|----------|--------|---------|
| agent-callbacks | passed | {'passed': 4, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 4} |
| cli-content | passed | {'passed': 7, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 7} |
| cli-core | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| cli-extra | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| cli-llm | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 2, 'recovered': 0, 'total': 2} |
| cli-ops | passed | {'passed': 10, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 10} |
| collect-failure-recovery | passed | {'passed': 1, 'failed': 0, 'unconfigured': 0, 'recovered': 1, 'total': 2} |
| collection | passed | {'passed': 5, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 5} |
| collection-monitor | passed | {'passed': 4, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 4} |
| collectors-e2e | passed | {'passed': 4, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 4} |
| cost-budget | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| cron-schedules | passed | {'passed': 5, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 5} |
| data-lifecycle-e2e | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 6, 'recovered': 0, 'total': 6} |
| data-privacy | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| delivery-channels | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| delivery-schedules | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| discovery | passed | {'passed': 5, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 5} |
| domain-management | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| enduser-journey | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 2, 'recovered': 0, 'total': 2} |
| enduser-lifecycle | passed | {'passed': 8, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 8} |
| enduser-preferences | passed | {'passed': 7, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 7} |
| error-boundary | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| kb-access | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| kb-draft | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| kb-extraction | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 2, 'recovered': 0, 'total': 2} |
| kb-graph | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| kb-import-export | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| kb-lifecycle | passed | {'passed': 8, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 8} |
| kb-promote | passed | {'passed': 4, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 4} |
| kb-versioning | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| keyword-management | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| llm-failure-recovery | passed | {'passed': 2, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 2} |
| llm-gated | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 3, 'recovered': 0, 'total': 3} |
| meta-validation | passed | {'passed': 2, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 2} |
| observability | passed | {'passed': 4, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 4} |
| output-column | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 2, 'recovered': 0, 'total': 2} |
| output-digest-report | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 3, 'recovered': 0, 'total': 3} |
| output-discovery | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| output-ebook | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 4, 'recovered': 0, 'total': 4} |
| output-premium-products | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 3, 'recovered': 0, 'total': 3} |
| output-simplify-recommend | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 2, 'recovered': 0, 'total': 2} |
| output-tutorial-presentation | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 3, 'recovered': 0, 'total': 3} |
| processing | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 2, 'recovered': 0, 'total': 2} |
| products-billing | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 8, 'recovered': 0, 'total': 8} |
| projects-config | passed | {'passed': 8, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 8} |
| quality-gate-config | passed | {'passed': 4, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 4} |
| rest-api | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 8, 'recovered': 0, 'total': 8} |
| source-management | passed | {'passed': 9, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 9} |
| sources-a6-keyed | unconfigured | {'passed': 0, 'failed': 0, 'unconfigured': 4, 'recovered': 0, 'total': 4} |
| sources-coverage | passed | {'passed': 4, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 4} |
| sources-gap-closure | passed | {'passed': 6, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 6} |
| system-health | passed | {'passed': 3, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 3} |
| topic-management | passed | {'passed': 5, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 5} |
| webhooks-alerts | passed | {'passed': 8, 'failed': 0, 'unconfigured': 0, 'recovered': 0, 'total': 8} |

## Artifacts

- `01-RAW/CrossRef/2026-08-07/119c67315384023e.json` (RAW, 382697B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/CrossRef/2026-08-07/119c67315384023e.json)
- `01-RAW/CrossRef/_runs.json` (RAW, 947B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/CrossRef/_runs.json)
- `01-RAW/Unpaywall/2026-07-29/3f897ddacb18e225.json` (RAW, 611B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/Unpaywall/2026-07-29/3f897ddacb18e225.json)
- `01-RAW/Unpaywall/2026-08-07/3f897ddacb18e225.json` (RAW, 611B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/Unpaywall/2026-08-07/3f897ddacb18e225.json)
- `01-RAW/Unpaywall/_runs.json` (RAW, 1243B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/Unpaywall/_runs.json)
- `01-RAW/arxiv/_runs.json` (RAW, 72775B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/arxiv/_runs.json)
- `01-RAW/pubmed/2026-07-28/42507351.json` (RAW, 3229B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-07-28/42507351.json)
- `01-RAW/pubmed/2026-07-28/42507389.json` (RAW, 2665B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-07-28/42507389.json)
- `01-RAW/pubmed/2026-07-28/42507401.json` (RAW, 3583B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-07-28/42507401.json)
- `01-RAW/pubmed/2026-07-29/42517280.json` (RAW, 3955B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-07-29/42517280.json)
- `01-RAW/pubmed/2026-07-29/42517714.json` (RAW, 3446B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-07-29/42517714.json)
- `01-RAW/pubmed/2026-07-29/42520328.json` (RAW, 3402B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-07-29/42520328.json)
- `01-RAW/pubmed/2026-07-29/42522050.json` (RAW, 3306B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-07-29/42522050.json)
- `01-RAW/pubmed/2026-08-07/42562071.json` (RAW, 3800B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562071.json)
- `01-RAW/pubmed/2026-08-07/42562157.json` (RAW, 3568B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562157.json)
- `01-RAW/pubmed/2026-08-07/42562184.json` (RAW, 4009B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562184.json)
- `01-RAW/pubmed/2026-08-07/42562226.json` (RAW, 3664B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562226.json)
- `01-RAW/pubmed/2026-08-07/42562247.json` (RAW, 3115B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562247.json)
- `01-RAW/pubmed/2026-08-07/42562263.json` (RAW, 3562B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562263.json)
- `01-RAW/pubmed/2026-08-07/42562351.json` (RAW, 4050B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562351.json)
- `01-RAW/pubmed/2026-08-07/42562364.json` (RAW, 3138B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562364.json)
- `01-RAW/pubmed/2026-08-07/42562392.json` (RAW, 3110B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562392.json)
- `01-RAW/pubmed/2026-08-07/42562395.json` (RAW, 3607B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562395.json)
- `01-RAW/pubmed/2026-08-07/42562442.json` (RAW, 2648B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562442.json)
- `01-RAW/pubmed/2026-08-07/42562584.json` (RAW, 3524B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562584.json)
- `01-RAW/pubmed/2026-08-07/42562585.json` (RAW, 4766B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562585.json)
- `01-RAW/pubmed/2026-08-07/42562620.json` (RAW, 2771B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562620.json)
- `01-RAW/pubmed/2026-08-07/42562661.json` (RAW, 3274B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562661.json)
- `01-RAW/pubmed/2026-08-07/42562721.json` (RAW, 3059B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562721.json)
- `01-RAW/pubmed/2026-08-07/42562722.json` (RAW, 2662B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562722.json)
- `01-RAW/pubmed/2026-08-07/42562748.json` (RAW, 3209B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562748.json)
- `01-RAW/pubmed/2026-08-07/42562782.json` (RAW, 3596B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562782.json)
- `01-RAW/pubmed/2026-08-07/42562810.json` (RAW, 3458B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/2026-08-07/42562810.json)
- `01-RAW/pubmed/_runs.json` (RAW, 258794B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/pubmed/_runs.json)
- `01-RAW/uspto/_runs.json` (RAW, 4133B, PASS, from /mnt/d/贯维/AutoInfo/collections/medical-research/uspto/_runs.json)
- `02-PROCESSED/pipeline-2026-07-25.log` (PROCESSED, 375926B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-07-25.log)
- `02-PROCESSED/pipeline-2026-07-26.log` (PROCESSED, 19738B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-07-26.log)
- `02-PROCESSED/pipeline-2026-07-27.log` (PROCESSED, 287702B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-07-27.log)
- `02-PROCESSED/pipeline-2026-07-28.log` (PROCESSED, 289357B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-07-28.log)
- `02-PROCESSED/pipeline-2026-07-29.log` (PROCESSED, 292096B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-07-29.log)
- `02-PROCESSED/pipeline-2026-07-30.log` (PROCESSED, 296562B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-07-30.log)
- `02-PROCESSED/pipeline-2026-07-31.log` (PROCESSED, 281205B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-07-31.log)
- `02-PROCESSED/pipeline-2026-08-02.log` (PROCESSED, 725698B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-08-02.log)
- `02-PROCESSED/pipeline-2026-08-03.log` (PROCESSED, 262342B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-08-03.log)
- `02-PROCESSED/pipeline-2026-08-04.log` (PROCESSED, 213688B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-08-04.log)
- `02-PROCESSED/pipeline-2026-08-05.log` (PROCESSED, 677406B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-08-05.log)
- `02-PROCESSED/pipeline-2026-08-06.log` (PROCESSED, 328013B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-08-06.log)
- `02-PROCESSED/pipeline-2026-08-07.log` (PROCESSED, 108483B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-08-07.log)
- `02-PROCESSED/pipeline-2026-08-08.log` (PROCESSED, 21133B, PASS, from /mnt/d/贯维/AutoInfo/logs/pipeline-2026-08-08.log)
- `01-RAW/01-Raw/Anti-Müllerian hormone/2026-07-29-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md` (RAW, 2908B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Anti-Müllerian hormone/2026-07-29-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md)
- `01-RAW/01-Raw/Anti-Müllerian hormone/2026-08-03-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md` (RAW, 2929B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Anti-Müllerian hormone/2026-08-03-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md)
- `01-RAW/01-Raw/Clinical outcomes/2026-07-29-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md` (RAW, 3576B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Clinical outcomes/2026-07-29-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md)
- `01-RAW/01-Raw/Clinical outcomes/2026-08-03-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md` (RAW, 3597B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Clinical outcomes/2026-08-03-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md)
- `01-RAW/01-Raw/Herpes simplex virus/2026-07-29-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md` (RAW, 2685B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Herpes simplex virus/2026-07-29-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md)
- `01-RAW/01-Raw/Herpes simplex virus/2026-08-03-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md` (RAW, 2706B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Herpes simplex virus/2026-08-03-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md)
- `01-RAW/01-Raw/IVF/2026-07-24-qa-article.md` (RAW, 339B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/IVF/2026-07-24-qa-article.md)
- `01-RAW/01-Raw/IVF/2026-08-05-ivf-embryo-time-lapse-study.md` (RAW, 556B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/IVF/2026-08-05-ivf-embryo-time-lapse-study.md)
- `01-RAW/01-Raw/MASCAL/2026-07-29-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md` (RAW, 2138B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/MASCAL/2026-07-29-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md)
- `01-RAW/01-Raw/MASCAL/2026-08-03-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md` (RAW, 2159B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/MASCAL/2026-08-03-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md)
- `01-RAW/01-Raw/crispr/2026-08-05-crispr-clinical-trial-update.md` (RAW, 518B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/crispr/2026-08-05-crispr-clinical-trial-update.md)
- `01-RAW/01-Raw/diabetic/2026-07-29-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md` (RAW, 2796B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/diabetic/2026-07-29-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md)
- `01-RAW/01-Raw/diabetic/2026-08-03-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md` (RAW, 2817B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/diabetic/2026-08-03-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md)
- `01-RAW/01-Raw/general/2026-07-29-.md` (RAW, 646B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-29-.md)
- `01-RAW/01-Raw/general/2026-07-31-ai-powered-drug-discovery-in-2026.md` (RAW, 533B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-31-ai-powered-drug-discovery-in-2026.md)
- `01-RAW/01-Raw/general/2026-07-31-crispr-gene-editing-advances-in-2026.md` (RAW, 535B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-31-crispr-gene-editing-advances-in-2026.md)
- `01-RAW/01-Raw/general/2026-07-31-mrna-vaccine-platform-beyond-covid-19.md` (RAW, 525B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-31-mrna-vaccine-platform-beyond-covid-19.md)
- `01-RAW/01-Raw/general/2026-08-03-import-test-entry-v2.md` (RAW, 534B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-03-import-test-entry-v2.md)
- `01-RAW/01-Raw/general/2026-08-03-validation-import-entry.md` (RAW, 556B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-03-validation-import-entry.md)
- `01-RAW/01-Raw/general/2026-08-03-validation-test-unique-title-xyz.md` (RAW, 530B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-03-validation-test-unique-title-xyz.md)
- `01-RAW/01-Raw/general/2026-08-04-validation-import-entry.md` (RAW, 556B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-04-validation-import-entry.md)
- `01-RAW/01-Raw/general/2026-08-05-embryo-grading-ai.md` (RAW, 502B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-05-embryo-grading-ai.md)
- `01-RAW/01-Raw/general/2026-08-05-validation-import-entry.md` (RAW, 569B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-05-validation-import-entry.md)
- `01-RAW/01-Raw/in vitro fertilization (IVF)/2026-07-29-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md` (RAW, 2387B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/in vitro fertilization (IVF)/2026-07-29-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md)
- `01-RAW/01-Raw/in vitro fertilization (IVF)/2026-08-03-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md` (RAW, 2408B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/in vitro fertilization (IVF)/2026-08-03-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md)
- `01-RAW/01-Raw/lumbopelvic pain/2026-08-03-non-pharmacological-interventions-for-the-treatment-of-lumbopelvic-pain-in-pregnant-women-a-systematic-review-protocol-using-the-tidier-checklist.md` (RAW, 2762B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/lumbopelvic pain/2026-08-03-non-pharmacological-interventions-for-the-treatment-of-lumbopelvic-pain-in-pregnant-women-a-systematic-review-protocol-using-the-tidier-checklist.md)
- `01-RAW/01-Raw/validation-test/2026-08-03-validation-test-entry.md` (RAW, 524B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/validation-test/2026-08-03-validation-test-entry.md)
- `03-KB/02-Draft/general/2026-08-03-mrna-validation-draft.md` (KB, 779B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/02-Draft/general/2026-08-03-mrna-validation-draft.md)
- `01-RAW/01-Raw/Anti-Müllerian hormone/2026-07-29-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md` (RAW, 2908B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Anti-Müllerian hormone/2026-07-29-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md)
- `01-RAW/01-Raw/Anti-Müllerian hormone/2026-08-03-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md` (RAW, 2929B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Anti-Müllerian hormone/2026-08-03-analytical-reliability-and-patient-experience-of-a-microblade-based-self-collection-device-for-reproductive-hormone-monitoring-a-paired-sample-pilot-study.md)
- `01-RAW/01-Raw/Clinical outcomes/2026-07-29-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md` (RAW, 3576B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Clinical outcomes/2026-07-29-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md)
- `01-RAW/01-Raw/Clinical outcomes/2026-08-03-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md` (RAW, 3597B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Clinical outcomes/2026-08-03-clinical-validity-of-midway-pgt-a-a-comparative-study-with-traditional-pgt-a-and-analysis-of-fertilization-strategies.md)
- `01-RAW/01-Raw/Herpes simplex virus/2026-07-29-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md` (RAW, 2685B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Herpes simplex virus/2026-07-29-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md)
- `01-RAW/01-Raw/Herpes simplex virus/2026-08-03-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md` (RAW, 2706B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/Herpes simplex virus/2026-08-03-surface-engineered-nanocarrier-based-drug-delivery-systems-for-the-management-of-herpes-simplex-virus.md)
- `01-RAW/01-Raw/IVF/2026-07-24-qa-article.md` (RAW, 339B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/IVF/2026-07-24-qa-article.md)
- `01-RAW/01-Raw/IVF/2026-08-05-ivf-embryo-time-lapse-study.md` (RAW, 556B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/IVF/2026-08-05-ivf-embryo-time-lapse-study.md)
- `01-RAW/01-Raw/MASCAL/2026-07-29-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md` (RAW, 2138B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/MASCAL/2026-07-29-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md)
- `01-RAW/01-Raw/MASCAL/2026-08-03-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md` (RAW, 2159B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/MASCAL/2026-08-03-casualty-management-in-eastern-ukraine-and-the-application-of-the-eight-domains-of-mass-casualty-management.md)
- `01-RAW/01-Raw/crispr/2026-08-05-crispr-clinical-trial-update.md` (RAW, 518B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/crispr/2026-08-05-crispr-clinical-trial-update.md)
- `01-RAW/01-Raw/diabetic/2026-07-29-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md` (RAW, 2796B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/diabetic/2026-07-29-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md)
- `01-RAW/01-Raw/diabetic/2026-08-03-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md` (RAW, 2817B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/diabetic/2026-08-03-the-clinical-effectiveness-of-traditional-chinese-medicine-in-treating-diabetes-related-pruritus-a-systematic-review-and-meta-analysis.md)
- `01-RAW/01-Raw/general/2026-07-29-.md` (RAW, 646B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-29-.md)
- `01-RAW/01-Raw/general/2026-07-31-ai-powered-drug-discovery-in-2026.md` (RAW, 533B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-31-ai-powered-drug-discovery-in-2026.md)
- `01-RAW/01-Raw/general/2026-07-31-crispr-gene-editing-advances-in-2026.md` (RAW, 535B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-31-crispr-gene-editing-advances-in-2026.md)
- `01-RAW/01-Raw/general/2026-07-31-mrna-vaccine-platform-beyond-covid-19.md` (RAW, 525B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-07-31-mrna-vaccine-platform-beyond-covid-19.md)
- `01-RAW/01-Raw/general/2026-08-03-import-test-entry-v2.md` (RAW, 534B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-03-import-test-entry-v2.md)
- `01-RAW/01-Raw/general/2026-08-03-validation-import-entry.md` (RAW, 556B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-03-validation-import-entry.md)
- `01-RAW/01-Raw/general/2026-08-03-validation-test-unique-title-xyz.md` (RAW, 530B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-03-validation-test-unique-title-xyz.md)
- `01-RAW/01-Raw/general/2026-08-04-validation-import-entry.md` (RAW, 556B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-04-validation-import-entry.md)
- `01-RAW/01-Raw/general/2026-08-05-embryo-grading-ai.md` (RAW, 502B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-05-embryo-grading-ai.md)
- `01-RAW/01-Raw/general/2026-08-05-validation-import-entry.md` (RAW, 569B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/general/2026-08-05-validation-import-entry.md)
- `01-RAW/01-Raw/in vitro fertilization (IVF)/2026-07-29-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md` (RAW, 2387B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/in vitro fertilization (IVF)/2026-07-29-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md)
- `01-RAW/01-Raw/in vitro fertilization (IVF)/2026-08-03-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md` (RAW, 2408B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/in vitro fertilization (IVF)/2026-08-03-ivf-or-icsi-selection-stratified-by-sperm-head-morphology.md)
- `01-RAW/01-Raw/lumbopelvic pain/2026-08-03-non-pharmacological-interventions-for-the-treatment-of-lumbopelvic-pain-in-pregnant-women-a-systematic-review-protocol-using-the-tidier-checklist.md` (RAW, 2762B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/lumbopelvic pain/2026-08-03-non-pharmacological-interventions-for-the-treatment-of-lumbopelvic-pain-in-pregnant-women-a-systematic-review-protocol-using-the-tidier-checklist.md)
- `01-RAW/01-Raw/validation-test/2026-08-03-validation-test-entry.md` (RAW, 524B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/01-Raw/validation-test/2026-08-03-validation-test-entry.md)
- `03-KB/02-Draft/general/2026-08-03-mrna-validation-draft.md` (KB, 779B, PASS, from /mnt/d/贯维/AutoInfo/knowledge/medical-research/02-Draft/general/2026-08-03-mrna-validation-draft.md)

## Rejected Artifacts (failed delivery gates)

- `06-REJECTED/_failed/qa-test-item-1.json` — authenticity: entry[0] placeholder source_url: https://example.com/article; entry[0] missing source_type; entry[0] missing source_platform (from /mnt/d/贯维/AutoInfo/collections/medical/_failed/qa-test-item-1.json)
- `06-REJECTED/_failed/test-item-g4-retry.json` — authenticity: entry[0] placeholder source_url: https://example.com/article; entry[0] missing source_type; entry[0] missing source_platform (from /mnt/d/贯维/AutoInfo/collections/medical-research/_failed/test-item-g4-retry.json)
- `06-REJECTED/_failed/test-g4-int-chain.json` — authenticity: entry[0] placeholder source_url: https://example.com/article; entry[0] missing source_type; entry[0] missing source_platform (from /mnt/d/贯维/AutoInfo/collections/test/_failed/test-g4-int-chain.json)
- `06-REJECTED/scenarios.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/2026-08-06_235925_105943/scenarios.json)
- `06-REJECTED/coverage-2026-08-06_181414.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181414.json)
- `06-REJECTED/coverage-2026-08-06_181608.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181608.json)
- `06-REJECTED/coverage-2026-08-06_181708.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181708.json)
- `06-REJECTED/coverage-2026-08-06_181729.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181729.json)
- `06-REJECTED/coverage-2026-08-06_181734.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181734.json)
- `06-REJECTED/coverage-2026-08-06_181739.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181739.json)
- `06-REJECTED/coverage-2026-08-06_181823.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181823.json)
- `06-REJECTED/coverage-2026-08-06_181824.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181824.json)
- `06-REJECTED/coverage-2026-08-06_181844.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181844.json)
- `06-REJECTED/coverage-2026-08-06_181845.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181845.json)
- `06-REJECTED/coverage-2026-08-06_182651.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_182651.json)
- `06-REJECTED/coverage-2026-08-06_185114.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_185114.json)
- `06-REJECTED/coverage-2026-08-06_185521.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_185521.json)
- `06-REJECTED/coverage-2026-08-06_192656.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_192656.json)
- `06-REJECTED/coverage-2026-08-06_195147.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_195147.json)
- `06-REJECTED/coverage-2026-08-06_195726.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_195726.json)
- `06-REJECTED/coverage-2026-08-06_201551.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_201551.json)
- `06-REJECTED/coverage-2026-08-06_205634.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_205634.json)
- `06-REJECTED/coverage-2026-08-06_212009.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212009.json)
- `06-REJECTED/coverage-2026-08-06_212420.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212420.json)
- `06-REJECTED/coverage-2026-08-06_212441.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212441.json)
- `06-REJECTED/coverage-2026-08-06_212450.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212450.json)
- `06-REJECTED/coverage-2026-08-06_212553.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212553.json)
- `06-REJECTED/coverage-2026-08-06_212618.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212618.json)
- `06-REJECTED/coverage-2026-08-06_212736.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212736.json)
- `06-REJECTED/coverage-2026-08-06_213927.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_213927.json)
- `06-REJECTED/coverage-2026-08-06_214016.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214016.json)
- `06-REJECTED/coverage-2026-08-06_214054.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214054.json)
- `06-REJECTED/coverage-2026-08-06_214147.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214147.json)
- `06-REJECTED/coverage-2026-08-06_214304.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214304.json)
- `06-REJECTED/coverage-2026-08-06_214408.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214408.json)
- `06-REJECTED/coverage-2026-08-06_214436.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214436.json)
- `06-REJECTED/coverage-2026-08-06_214653.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214653.json)
- `06-REJECTED/coverage-2026-08-06_214814.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214814.json)
- `06-REJECTED/coverage-2026-08-06_220716.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220716.json)
- `06-REJECTED/coverage-2026-08-06_220911.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220911.json)
- `06-REJECTED/coverage-2026-08-06_220913.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220913.json)
- `06-REJECTED/coverage-2026-08-06_220915.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220915.json)
- `06-REJECTED/coverage-2026-08-06_221033.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221033.json)
- `06-REJECTED/coverage-2026-08-06_221035.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221035.json)
- `06-REJECTED/coverage-2026-08-06_221037.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221037.json)
- `06-REJECTED/coverage-2026-08-06_221111.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221111.json)
- `06-REJECTED/coverage-2026-08-06_221129.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221129.json)
- `06-REJECTED/coverage-2026-08-06_221130.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221130.json)
- `06-REJECTED/coverage-2026-08-06_221132.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221132.json)
- `06-REJECTED/coverage-2026-08-06_231741.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_231741.json)
- `06-REJECTED/coverage-2026-08-06_231743.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_231743.json)
- `06-REJECTED/coverage-2026-08-06_231745.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_231745.json)
- `06-REJECTED/coverage-2026-08-06_233034.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_233034.json)
- `06-REJECTED/coverage-2026-08-07_000304.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_000304.json)
- `06-REJECTED/coverage-2026-08-07_001029.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_001029.json)
- `06-REJECTED/coverage-2026-08-07_004745.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_004745.json)
- `06-REJECTED/coverage-2026-08-07_004747.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_004747.json)
- `06-REJECTED/coverage-2026-08-07_011833.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_011833.json)
- `06-REJECTED/coverage-2026-08-07_011836.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_011836.json)
- `06-REJECTED/coverage-2026-08-07_011838.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_011838.json)
- `06-REJECTED/coverage-2026-08-07_013200.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013200.json)
- `06-REJECTED/coverage-2026-08-07_013212.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013212.json)
- `06-REJECTED/coverage-2026-08-07_013214.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013214.json)
- `06-REJECTED/coverage-2026-08-07_013216.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013216.json)
- `06-REJECTED/coverage-2026-08-07_122148.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_122148.json)
- `06-REJECTED/coverage-2026-08-07_122152.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_122152.json)
- `06-REJECTED/coverage-2026-08-07_135131.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_135131.json)
- `06-REJECTED/coverage-2026-08-07_142137.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_142137.json)
- `06-REJECTED/coverage-2026-08-07_142833.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_142833.json)
- `06-REJECTED/coverage-2026-08-07_142838.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_142838.json)
- `06-REJECTED/coverage-2026-08-07_145940.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_145940.json)
- `06-REJECTED/coverage-2026-08-07_145947.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_145947.json)
- `06-REJECTED/coverage-2026-08-07_151029.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151029.json)
- `06-REJECTED/coverage-2026-08-07_151039.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151039.json)
- `06-REJECTED/coverage-2026-08-07_151104.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151104.json)
- `06-REJECTED/coverage-2026-08-07_151132.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151132.json)
- `06-REJECTED/coverage-2026-08-07_151203.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151203.json)
- `06-REJECTED/coverage-2026-08-07_151329.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151329.json)
- `06-REJECTED/coverage-2026-08-08_031831.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-08_031831.json)
- `06-REJECTED/matrix-report.md` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/outputs/coverage-matrix/matrix-report.md)
- `06-REJECTED/autoinfo-export-medical-research-20260723T035442Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] missing source_url; entry[1] missing source_url; entry[2] missing source_url; entry[3] missing source_url; entry[4] missing source_url (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260723T035442Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260723T044949Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] missing source_url; entry[1] missing source_url; entry[2] missing source_url; entry[3] missing source_url; entry[4] missing source_url (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260723T044949Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T120452Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/ai-drug-discovery; entry[1] placeholder source_url: https://example.com/mrna-vaccine; entry[2] placeholder source_url: https://example.com/crispr-2026; entry[3] missing source_url; entry[3] missing source_platform; entry[4] missing source_url ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T120452Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T121334Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T121334Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T124032Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T124032Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T124714Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T124714Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T125804Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T125804Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T131719Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T131719Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T132429Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T132429Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T132942Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T132942Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T140105Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T140105Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T140556Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T140556Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T142657Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T142657Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260803T143056Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/kb-draft-scenario; entry[2] placeholder source_url: https://example.com/validation-test-2; entry[3] placeholder source_url: https://example.com/import-test-v2; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260803T143056Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260804T100739Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] missing source_url; entry[1] missing source_platform; entry[2] missing source_url; entry[2] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260804T100739Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260804T100829Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] missing source_url; entry[1] missing source_platform; entry[2] missing source_url; entry[2] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260804T100829Z.json)
- `06-REJECTED/autoinfo-export-medical-research-20260805T091034Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations']; authenticity: entry[0] placeholder source_url: https://example.com/validation-import; entry[0] missing source_platform; entry[1] placeholder source_url: https://example.com/parity-t49; entry[1] missing source_platform; entry[2] missing source_platform; entry[3] missing source_platform ... (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-medical-research-20260805T091034Z.json)
- `06-REJECTED/autoinfo-export-nonexistent-domain-20260723T035435Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-nonexistent-domain-20260723T035435Z.json)
- `06-REJECTED/autoinfo-export-test-20260723T044801Z.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/exports/autoinfo-export-test-20260723T044801Z.json)
- `06-REJECTED/scenarios.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/2026-08-06_235925_105943/scenarios.json)
- `06-REJECTED/coverage-2026-08-06_181414.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181414.json)
- `06-REJECTED/coverage-2026-08-06_181608.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181608.json)
- `06-REJECTED/coverage-2026-08-06_181708.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181708.json)
- `06-REJECTED/coverage-2026-08-06_181729.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181729.json)
- `06-REJECTED/coverage-2026-08-06_181734.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181734.json)
- `06-REJECTED/coverage-2026-08-06_181739.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181739.json)
- `06-REJECTED/coverage-2026-08-06_181823.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181823.json)
- `06-REJECTED/coverage-2026-08-06_181824.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181824.json)
- `06-REJECTED/coverage-2026-08-06_181844.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181844.json)
- `06-REJECTED/coverage-2026-08-06_181845.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_181845.json)
- `06-REJECTED/coverage-2026-08-06_182651.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_182651.json)
- `06-REJECTED/coverage-2026-08-06_185114.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_185114.json)
- `06-REJECTED/coverage-2026-08-06_185521.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_185521.json)
- `06-REJECTED/coverage-2026-08-06_192656.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_192656.json)
- `06-REJECTED/coverage-2026-08-06_195147.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_195147.json)
- `06-REJECTED/coverage-2026-08-06_195726.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_195726.json)
- `06-REJECTED/coverage-2026-08-06_201551.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_201551.json)
- `06-REJECTED/coverage-2026-08-06_205634.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_205634.json)
- `06-REJECTED/coverage-2026-08-06_212009.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212009.json)
- `06-REJECTED/coverage-2026-08-06_212420.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212420.json)
- `06-REJECTED/coverage-2026-08-06_212441.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212441.json)
- `06-REJECTED/coverage-2026-08-06_212450.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212450.json)
- `06-REJECTED/coverage-2026-08-06_212553.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212553.json)
- `06-REJECTED/coverage-2026-08-06_212618.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212618.json)
- `06-REJECTED/coverage-2026-08-06_212736.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_212736.json)
- `06-REJECTED/coverage-2026-08-06_213927.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_213927.json)
- `06-REJECTED/coverage-2026-08-06_214016.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214016.json)
- `06-REJECTED/coverage-2026-08-06_214054.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214054.json)
- `06-REJECTED/coverage-2026-08-06_214147.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214147.json)
- `06-REJECTED/coverage-2026-08-06_214304.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214304.json)
- `06-REJECTED/coverage-2026-08-06_214408.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214408.json)
- `06-REJECTED/coverage-2026-08-06_214436.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214436.json)
- `06-REJECTED/coverage-2026-08-06_214653.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214653.json)
- `06-REJECTED/coverage-2026-08-06_214814.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_214814.json)
- `06-REJECTED/coverage-2026-08-06_220716.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220716.json)
- `06-REJECTED/coverage-2026-08-06_220911.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220911.json)
- `06-REJECTED/coverage-2026-08-06_220913.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220913.json)
- `06-REJECTED/coverage-2026-08-06_220915.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_220915.json)
- `06-REJECTED/coverage-2026-08-06_221033.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221033.json)
- `06-REJECTED/coverage-2026-08-06_221035.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221035.json)
- `06-REJECTED/coverage-2026-08-06_221037.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221037.json)
- `06-REJECTED/coverage-2026-08-06_221111.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221111.json)
- `06-REJECTED/coverage-2026-08-06_221129.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221129.json)
- `06-REJECTED/coverage-2026-08-06_221130.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221130.json)
- `06-REJECTED/coverage-2026-08-06_221132.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_221132.json)
- `06-REJECTED/coverage-2026-08-06_231741.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_231741.json)
- `06-REJECTED/coverage-2026-08-06_231743.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_231743.json)
- `06-REJECTED/coverage-2026-08-06_231745.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_231745.json)
- `06-REJECTED/coverage-2026-08-06_233034.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-06_233034.json)
- `06-REJECTED/coverage-2026-08-07_000304.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_000304.json)
- `06-REJECTED/coverage-2026-08-07_001029.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_001029.json)
- `06-REJECTED/coverage-2026-08-07_004745.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_004745.json)
- `06-REJECTED/coverage-2026-08-07_004747.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_004747.json)
- `06-REJECTED/coverage-2026-08-07_011833.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_011833.json)
- `06-REJECTED/coverage-2026-08-07_011836.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_011836.json)
- `06-REJECTED/coverage-2026-08-07_011838.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_011838.json)
- `06-REJECTED/coverage-2026-08-07_013200.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013200.json)
- `06-REJECTED/coverage-2026-08-07_013212.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013212.json)
- `06-REJECTED/coverage-2026-08-07_013214.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013214.json)
- `06-REJECTED/coverage-2026-08-07_013216.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_013216.json)
- `06-REJECTED/coverage-2026-08-07_122148.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_122148.json)
- `06-REJECTED/coverage-2026-08-07_122152.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_122152.json)
- `06-REJECTED/coverage-2026-08-07_135131.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_135131.json)
- `06-REJECTED/coverage-2026-08-07_142137.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_142137.json)
- `06-REJECTED/coverage-2026-08-07_142833.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_142833.json)
- `06-REJECTED/coverage-2026-08-07_142838.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_142838.json)
- `06-REJECTED/coverage-2026-08-07_145940.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_145940.json)
- `06-REJECTED/coverage-2026-08-07_145947.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_145947.json)
- `06-REJECTED/coverage-2026-08-07_151029.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151029.json)
- `06-REJECTED/coverage-2026-08-07_151039.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151039.json)
- `06-REJECTED/coverage-2026-08-07_151104.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151104.json)
- `06-REJECTED/coverage-2026-08-07_151132.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151132.json)
- `06-REJECTED/coverage-2026-08-07_151203.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151203.json)
- `06-REJECTED/coverage-2026-08-07_151329.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-07_151329.json)
- `06-REJECTED/coverage-2026-08-08_031831.json` — D1: Missing sections: []; empty sections: ['key_findings', 'summary', 'recommendations'] (from /mnt/d/贯维/AutoInfo/validation-runs/coverage/coverage-2026-08-08_031831.json)

## Coverage Matrix (E8)

- Matrix report: `04-MATRIX/matrix-report.md`
- Cells: required=112, produced=0, gap=112, unconfigured=0, not-applicable=616
- LLM available: yes

### COVERAGE_GAP (required cells with no evidence)

- `medical-research × column × agent`
- `medical-research × column × audio`
- `medical-research × column × audiobook`
- `medical-research × column × epub`
- `medical-research × column × html`
- `medical-research × column × json`
- `medical-research × column × markdown`
- `medical-research × digest × agent`
- `medical-research × digest × audio`
- `medical-research × digest × audiobook`
- `medical-research × digest × epub`
- `medical-research × digest × html`
- `medical-research × digest × json`
- `medical-research × digest × markdown`
- `medical-research × enterprise-briefing × agent`
- `medical-research × enterprise-briefing × audio`
- `medical-research × enterprise-briefing × audiobook`
- `medical-research × enterprise-briefing × epub`
- `medical-research × enterprise-briefing × html`
- `medical-research × enterprise-briefing × json`
- `medical-research × enterprise-briefing × markdown`
- `medical-research × magazine-digest × agent`
- `medical-research × magazine-digest × audio`
- `medical-research × magazine-digest × audiobook`
- `medical-research × magazine-digest × epub`
- `medical-research × magazine-digest × html`
- `medical-research × magazine-digest × json`
- `medical-research × magazine-digest × markdown`
- `medical-research × premium-briefing × agent`
- `medical-research × premium-briefing × audio`
- `medical-research × premium-briefing × audiobook`
- `medical-research × premium-briefing × epub`
- `medical-research × premium-briefing × html`
- `medical-research × premium-briefing × json`
- `medical-research × premium-briefing × markdown`
- `medical-research × presentation × agent`
- `medical-research × presentation × audio`
- `medical-research × presentation × audiobook`
- `medical-research × presentation × epub`
- `medical-research × presentation × html`
- `medical-research × presentation × json`
- `medical-research × presentation × markdown`
- `medical-research × report × agent`
- `medical-research × report × audio`
- `medical-research × report × audiobook`
- `medical-research × report × epub`
- `medical-research × report × html`
- `medical-research × report × json`
- `medical-research × report × markdown`
- `medical-research × tutorial × agent`
- `medical-research × tutorial × audio`
- `medical-research × tutorial × audiobook`
- `medical-research × tutorial × epub`
- `medical-research × tutorial × html`
- `medical-research × tutorial × json`
- `medical-research × tutorial × markdown`
- `tech-ai-developer × column × agent`
- `tech-ai-developer × column × audio`
- `tech-ai-developer × column × audiobook`
- `tech-ai-developer × column × epub`
- `tech-ai-developer × column × html`
- `tech-ai-developer × column × json`
- `tech-ai-developer × column × markdown`
- `tech-ai-developer × digest × agent`
- `tech-ai-developer × digest × audio`
- `tech-ai-developer × digest × audiobook`
- `tech-ai-developer × digest × epub`
- `tech-ai-developer × digest × html`
- `tech-ai-developer × digest × json`
- `tech-ai-developer × digest × markdown`
- `tech-ai-developer × enterprise-briefing × agent`
- `tech-ai-developer × enterprise-briefing × audio`
- `tech-ai-developer × enterprise-briefing × audiobook`
- `tech-ai-developer × enterprise-briefing × epub`
- `tech-ai-developer × enterprise-briefing × html`
- `tech-ai-developer × enterprise-briefing × json`
- `tech-ai-developer × enterprise-briefing × markdown`
- `tech-ai-developer × magazine-digest × agent`
- `tech-ai-developer × magazine-digest × audio`
- `tech-ai-developer × magazine-digest × audiobook`
- `tech-ai-developer × magazine-digest × epub`
- `tech-ai-developer × magazine-digest × html`
- `tech-ai-developer × magazine-digest × json`
- `tech-ai-developer × magazine-digest × markdown`
- `tech-ai-developer × premium-briefing × agent`
- `tech-ai-developer × premium-briefing × audio`
- `tech-ai-developer × premium-briefing × audiobook`
- `tech-ai-developer × premium-briefing × epub`
- `tech-ai-developer × premium-briefing × html`
- `tech-ai-developer × premium-briefing × json`
- `tech-ai-developer × premium-briefing × markdown`
- `tech-ai-developer × presentation × agent`
- `tech-ai-developer × presentation × audio`
- `tech-ai-developer × presentation × audiobook`
- `tech-ai-developer × presentation × epub`
- `tech-ai-developer × presentation × html`
- `tech-ai-developer × presentation × json`
- `tech-ai-developer × presentation × markdown`
- `tech-ai-developer × report × agent`
- `tech-ai-developer × report × audio`
- `tech-ai-developer × report × audiobook`
- `tech-ai-developer × report × epub`
- `tech-ai-developer × report × html`
- `tech-ai-developer × report × json`
- `tech-ai-developer × report × markdown`
- `tech-ai-developer × tutorial × agent`
- `tech-ai-developer × tutorial × audio`
- `tech-ai-developer × tutorial × audiobook`
- `tech-ai-developer × tutorial × epub`
- `tech-ai-developer × tutorial × html`
- `tech-ai-developer × tutorial × json`
- `tech-ai-developer × tutorial × markdown`

## UX Metrics (issue #141)

- UX_OK: False (completion_rate=0.0 >= threshold 0.8)
- Journey: `enduser-journey` (status: unconfigured)
- Steps:
